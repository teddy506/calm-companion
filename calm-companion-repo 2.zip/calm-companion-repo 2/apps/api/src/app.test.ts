import { describe, expect, it } from "vitest";
import { buildApp } from "./app.js";
import { loadConfig } from "./config.js";

describe("app", () => {
  it("svarer på /health med sikkerhedsheaders", async () => {
    const app = await buildApp();
    const res = await app.inject({ method: "GET", url: "/health" });
    expect(res.statusCode).toBe(200);
    expect(res.headers["x-content-type-options"]).toBe("nosniff");
    await app.close();
  });
});

describe("config", () => {
  it("fejler uden DATABASE_URL", () => {
    expect(() => loadConfig({ NODE_ENV: "test" })).toThrow();
  });
  it("afviser dev-nøgle i production", () => {
    expect(() =>
      loadConfig({ NODE_ENV: "production", DATABASE_URL: "x", DEV_FIELD_KEY: "0".repeat(64) }),
    ).toThrow();
  });
});
