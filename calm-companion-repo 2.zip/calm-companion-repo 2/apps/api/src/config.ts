import { z } from "zod";

const schema = z.object({
  NODE_ENV: z.enum(["development", "test", "production"]).default("development"),
  PORT: z.coerce.number().int().default(3000),
  DATABASE_URL: z.string().min(1),
  // Kun til lokal udvikling. I test/prod bruges KMS/secrets manager.
  DEV_FIELD_KEY: z.string().regex(/^[0-9a-f]{64}$/).optional(),
});

export type Config = z.infer<typeof schema>;

export function loadConfig(env: NodeJS.ProcessEnv = process.env): Config {
  const cfg = schema.parse(env); // kaster ved manglende/ugyldig konfiguration (fail fast)
  if (cfg.NODE_ENV === "production" && cfg.DEV_FIELD_KEY) {
    throw new Error("DEV_FIELD_KEY må ikke bruges i production");
  }
  return cfg;
}
