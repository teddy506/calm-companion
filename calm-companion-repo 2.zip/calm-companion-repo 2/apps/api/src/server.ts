import { buildApp } from "./app.js";
import { loadConfig } from "./config.js";

const cfg = loadConfig();
const app = await buildApp();
await app.listen({ port: cfg.PORT, host: "0.0.0.0" });
